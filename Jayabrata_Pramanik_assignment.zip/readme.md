1. need to make .env file and DATABASE_URL, JWT_SECRET_KEY
2. npm install
3. npx prisma generate
4. npx prisma migrate dev --name init_schema
5. npx prisma generate --no-engine
6. npm run dev
